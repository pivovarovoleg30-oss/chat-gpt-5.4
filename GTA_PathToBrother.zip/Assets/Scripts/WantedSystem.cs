// Система розыска
using UnityEngine;
public class WantedSystem : MonoBehaviour {}