// Скрипт управления игроком
using UnityEngine;

public class PlayerController : MonoBehaviour {
    void Update() {
        // Движение игрока
    }
}