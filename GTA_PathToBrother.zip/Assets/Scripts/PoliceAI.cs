// Скрипт логики полиции
using UnityEngine;
public class PoliceAI : MonoBehaviour {}