// Скрипт диспетчера
using UnityEngine;
public class Dispatcher : MonoBehaviour {}