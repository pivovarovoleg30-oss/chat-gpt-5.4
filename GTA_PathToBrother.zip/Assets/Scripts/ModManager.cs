// Мод-менеджер
using UnityEngine;
public class ModManager : MonoBehaviour {}