// Скрипт ModManager.cs будет здесь
