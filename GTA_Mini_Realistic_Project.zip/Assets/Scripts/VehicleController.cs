// Скрипт VehicleController.cs будет здесь
