// Скрипт NPCSpawner.cs будет здесь
