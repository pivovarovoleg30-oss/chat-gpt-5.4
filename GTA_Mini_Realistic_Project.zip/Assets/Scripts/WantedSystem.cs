// Скрипт WantedSystem.cs будет здесь
