// Скрипт WeaponController.cs будет здесь
