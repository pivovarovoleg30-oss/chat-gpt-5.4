// Скрипт PoliceAI.cs будет здесь
